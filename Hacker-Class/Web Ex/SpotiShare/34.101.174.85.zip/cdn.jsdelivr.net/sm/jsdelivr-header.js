/**
 * Bundled by jsDelivr using Rollup v2.79.1 and Terser v5.19.0.
 * Original file: /npm/toastify-js@1.12.0/src/toastify.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */