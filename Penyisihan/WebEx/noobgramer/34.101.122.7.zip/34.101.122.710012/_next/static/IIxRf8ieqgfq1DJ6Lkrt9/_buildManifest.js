self.__BUILD_MANIFEST = {
    __rewrites: {
        beforeFiles: [],
        afterFiles: [],
        fallback: []
    },
    "/": ["static/chunks/pages/index-542f7be6cd3092e8.js"],
    "/_error": ["static/chunks/pages/_error-54de1933a164a1ff.js"],
    "/note/[note_id]": ["static/chunks/pages/note/[note_id]-c81b5bbe9f4c130f.js"],
    sortedPages: ["/", "/_app", "/_error", "/note/[note_id]"]
}, self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();