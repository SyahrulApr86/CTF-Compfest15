(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [405], {
        8312: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return n(85)
            }])
        },
        85: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                default: function() {
                    return o
                }
            });
            var a = n(5893),
                r = n(9008),
                i = n.n(r),
                s = n(7294);

            function o() {
                let [e, t] = (0, s.useState)(""), n = async e => {
                    e.preventDefault();
                    let n = e.target[0].value,
                        a = await fetch("/api/priv", {
                            method: "POST",
                            headers: {
                                Accept: "application/json",
                                "Content-Type": "application/json",
                                Authorization: "".concat(function(e) {
                                    let t = 0;
                                    for (let n = 0; n < e.length; n++) t += e.charCodeAt(n);
                                    return t + parseInt("99521534")
                                }("Once_Read_Delete_Permanently"))
                            },
                            body: JSON.stringify({
                                note: n
                            })
                        }),
                        r = await a.json();
                    200 == a.status ? (console.log(r), t("your note has been made at ".concat(window.location.origin, "/note/").concat(r.id))) : alert(r.message)
                };
                return (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsxs)(i(), {
                        children: [(0, a.jsx)("title", {
                            children: "PRivN0tes"
                        }), (0, a.jsx)("meta", {
                            name: "description",
                            content: "create destructible anda secure note"
                        }), (0, a.jsx)("meta", {
                            name: "viewport",
                            content: "width=device-width, initial-scale=1"
                        }), (0, a.jsx)("link", {
                            rel: "icon",
                            href: "/favicon.ico"
                        })]
                    }), (0, a.jsxs)("main", {
                        className: "w-screen h-screen bg-white flex flex-col items-center justify-start pt-10",
                        children: [(0, a.jsx)("h1", {
                            className: "text-6xl text-emerald-700 font-bold",
                            children: "PrivN0te"
                        }), (0, a.jsx)("p", {
                            className: "text-xl font-semibold text-gray-700 tracking-wider mt-5",
                            children: "create note that will be deleted after the first read!"
                        }), (0, a.jsx)("p", {
                            className: "p-4 rounded-md bg-emerald-100 text-center",
                            children: e
                        }), (0, a.jsxs)("form", {
                            method: "POST",
                            onSubmit: n,
                            className: "mt-4 flex flex-col items-end gap-y-2",
                            children: [(0, a.jsx)("textarea", {
                                name: "note",
                                className: "border-2 border-gray-400 rounded-lg w-[700px] h-[400px]",
                                style: {
                                    resize: "none"
                                }
                            }), (0, a.jsx)("button", {
                                type: "submit",
                                className: "py-2 px-3 rounded-md bg-blue-500 text-white font-semibold hover:bg-blue-700",
                                children: "create"
                            })]
                        })]
                    })]
                })
            }
        },
        9008: function(e, t, n) {
            e.exports = n(2636)
        }
    },
    function(e) {
        e.O(0, [774, 888, 179], function() {
            return e(e.s = 8312)
        }), _N_E = e.O()
    }
]);