(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [888], {
        6840: function(n, u, t) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/_app", function() {
                return t(9212)
            }])
        },
        9212: function(n, u, t) {
            "use strict";
            t.r(u), t.d(u, {
                default: function() {
                    return _
                }
            });
            var r = t(5893);

            function _(n) {
                let {
                    Component: u,
                    pageProps: t
                } = n;
                return (0, r.jsx)(u, { ...t
                })
            }
            t(7952)
        },
        7952: function() {}
    },
    function(n) {
        var u = function(u) {
            return n(n.s = u)
        };
        n.O(0, [774, 179], function() {
            return u(6840), u(6885)
        }), _N_E = n.O()
    }
]);