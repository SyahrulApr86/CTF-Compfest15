(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [931], {
        4700: function(e, t, r) {
            Promise.resolve().then(r.bind(r, 9848)), Promise.resolve().then(r.bind(r, 2894))
        },
        9295: function(e, t, r) {
            "use strict";
            r.d(t, {
                W: function() {
                    return o
                },
                n: function() {
                    return a
                }
            }), r(1491), r(1014);
            var n = r(9838),
                a = (0, n.Z)("807327ad06ea0a59e303942021db476bd6bf9eaa"),
                o = (0, n.Z)("78a67fd227478c9f84cda58629c8cfd5afd7c002")
        },
        9848: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                default: function() {
                    return s
                }
            });
            var n = r(3955),
                a = r(9295),
                o = r(2310);

            function s() {
                let e = (0, o.useRef)(null);
                return (0, n.jsxs)("form", {
                    className: "flex flex-col gap-4 max-w-2xl w-full",
                    ref: e,
                    action: async t => {
                        var r, n, o;
                        null === (r = e.current) || void 0 === r || r.reset(), await (0, a.n)(null !== (o = null === (n = t.get("question")) || void 0 === n ? void 0 : n.toString()) && void 0 !== o ? o : "")
                    },
                    children: [(0, n.jsx)("textarea", {
                        className: "p-2 w-full border border-white bg-black rounded-md",
                        name: "question",
                        required: !0,
                        rows: 4
                    }), (0, n.jsx)("button", {
                        type: "submit",
                        className: "px-4 py-2 border border-white font-semibold rounded-md w-full",
                        children: "Ask"
                    })]
                })
            }
        },
        2894: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                default: function() {
                    return s
                }
            });
            var n = r(3955),
                a = r(9295),
                o = r(2310);

            function s(e) {
                let {
                    question: t,
                    isAdmin: r,
                    className: s
                } = e, l = (0, o.useRef)(null);
                return (0, n.jsxs)("div", {
                    className: "rounded-md p-4 flex flex-col gap-2 border border-black ".concat(s),
                    children: [(0, n.jsx)("p", {
                        children: t.question
                    }), (0, n.jsx)("hr", {
                        className: "border-t-2 border-black"
                    }), (0, n.jsx)("p", {
                        children: t.answer || "No answer yet"
                    }), "true" === r.toString().substring(0, 1) && (0, n.jsxs)("form", {
                        className: "flex flex-row gap-4 w-full",
                        ref: l,
                        action: async e => {
                            var r, n, o;
                            null === (r = l.current) || void 0 === r || r.reset(), await (0, a.W)(null !== (o = null === (n = e.get("answer")) || void 0 === n ? void 0 : n.toString()) && void 0 !== o ? o : "", t.id)
                        },
                        children: [(0, n.jsx)("input", {
                            className: "hidden",
                            name: "id",
                            value: t.id
                        }), (0, n.jsx)("textarea", {
                            className: "p-2 w-full border border-black rounded-md",
                            name: "answer",
                            required: !0,
                            rows: 1
                        }), (0, n.jsx)("button", {
                            type: "submit",
                            className: "px-4 py-2 border border-black font-semibold rounded-md",
                            children: "Send"
                        })]
                    })]
                })
            }
        },
        9838: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "Z", {
                enumerable: !0,
                get: function() {
                    return a
                }
            });
            let n = r(1491);

            function a(e) {
                let {
                    createServerReference: t
                } = "undefined" == typeof window ? r(6722) : r(8726);
                return t(e, n.callServer)
            }
        },
        1014: function(e, t) {},
        3009: function(e, t, r) {
            "use strict";
            /**
             * @license React
             * react-jsx-runtime.production.min.js
             *
             * Copyright (c) Meta Platforms, Inc. and affiliates.
             *
             * This source code is licensed under the MIT license found in the
             * LICENSE file in the root directory of this source tree.
             */
            var n = r(2310),
                a = Symbol.for("react.element"),
                o = (Symbol.for("react.fragment"), Object.prototype.hasOwnProperty),
                s = n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                l = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function u(e, t, r) {
                var n, u = {},
                    i = null,
                    c = null;
                for (n in void 0 !== r && (i = "" + r), void 0 !== t.key && (i = "" + t.key), void 0 !== t.ref && (c = t.ref), t) o.call(t, n) && !l.hasOwnProperty(n) && (u[n] = t[n]);
                if (e && e.defaultProps)
                    for (n in t = e.defaultProps) void 0 === u[n] && (u[n] = t[n]);
                return {
                    $$typeof: a,
                    type: e,
                    key: i,
                    ref: c,
                    props: u,
                    _owner: s.current
                }
            }
            t.jsx = u, t.jsxs = u
        },
        3955: function(e, t, r) {
            "use strict";
            e.exports = r(3009)
        },
        6246: function(e, t, r) {
            "use strict";
            /**
             * @license React
             * react-server-dom-webpack-client.edge.production.min.js
             *
             * Copyright (c) Meta Platforms, Inc. and affiliates.
             *
             * This source code is licensed under the MIT license found in the
             * LICENSE file in the root directory of this source tree.
             */
            var n = r(2784),
                a = r(2310),
                o = {
                    stream: !0
                },
                s = new Map,
                l = new Map;

            function u() {}
            var i = n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.Dispatcher,
                c = Symbol.for("react.element"),
                f = Symbol.for("react.lazy"),
                d = Symbol.for("react.default_value"),
                p = Symbol.iterator,
                v = Array.isArray,
                h = new WeakMap,
                m = new WeakMap;

            function b(e) {
                var t = h.get(this);
                if (!t) throw Error("Tried to encode a Server Action from a different instance than the encoder is from. This is a bug in React.");
                var r = null;
                if (null !== t.bound) {
                    if ((r = m.get(t)) || (n = t, s = new Promise(function(e, t) {
                            a = e, o = t
                        }), l = n, u = function(e) {
                            if ("string" == typeof e) {
                                var t = new FormData;
                                t.append("0", e), e = t
                            }
                            s.status = "fulfilled", s.value = e, a(e)
                        }, i = function(e) {
                            s.status = "rejected", s.reason = e, o(e)
                        }, c = 1, f = 0, d = null, l = JSON.stringify(l, function e(t, r) {
                            if (null === r) return null;
                            if ("object" == typeof r) {
                                if ("function" == typeof r.then) {
                                    null === d && (d = new FormData), f++;
                                    var n, a, o = c++;
                                    return r.then(function(t) {
                                        t = JSON.stringify(t, e);
                                        var r = d;
                                        r.append("" + o, t), 0 == --f && u(r)
                                    }, function(e) {
                                        i(e)
                                    }), "$@" + o.toString(16)
                                }
                                if (r instanceof FormData) {
                                    null === d && (d = new FormData);
                                    var s = d,
                                        l = "" + (t = c++) + "_";
                                    return r.forEach(function(e, t) {
                                        s.append(l + t, e)
                                    }), "$K" + t.toString(16)
                                }
                                return !v(r) && (null === (a = r) || "object" != typeof a ? null : "function" == typeof(a = p && a[p] || a["@@iterator"]) ? a : null) ? Array.from(r) : r
                            }
                            if ("string" == typeof r) return "Z" === r[r.length - 1] && this[t] instanceof Date ? "$D" + r : r = "$" === r[0] ? "$" + r : r;
                            if ("boolean" == typeof r) return r;
                            if ("number" == typeof r) return Number.isFinite(n = r) ? 0 === n && -1 / 0 == 1 / n ? "$-0" : n : 1 / 0 === n ? "$Infinity" : -1 / 0 === n ? "$-Infinity" : "$NaN";
                            if (void 0 === r) return "$undefined";
                            if ("function" == typeof r) {
                                if (void 0 !== (r = h.get(r))) return r = JSON.stringify(r, e), null === d && (d = new FormData), t = c++, d.set("" + t, r), "$F" + t.toString(16);
                                throw Error("Client Functions cannot be passed directly to Server Functions. Only Functions passed from the Server can be passed back again.")
                            }
                            if ("symbol" == typeof r) {
                                if (Symbol.for(t = r.description) !== r) throw Error("Only global symbols received from Symbol.for(...) can be passed to Server Functions. The symbol Symbol.for(" + r.description + ") cannot be found among global symbols.");
                                return "$S" + t
                            }
                            if ("bigint" == typeof r) return "$n" + r.toString(10);
                            throw Error("Type " + typeof r + " is not supported as an argument to a Server Function.")
                        }), null === d ? u(l) : (d.set("0", l), 0 === f && u(d)), r = s, m.set(t, r)), "rejected" === r.status) throw r.reason;
                    if ("fulfilled" !== r.status) throw r;
                    t = r.value;
                    var n, a, o, s, l, u, i, c, f, d, b = new FormData;
                    t.forEach(function(t, r) {
                        b.append("$ACTION_" + e + ":" + r, t)
                    }), r = b, t = "$ACTION_REF_" + e
                } else t = "$ACTION_ID_" + t.id;
                return {
                    name: t,
                    method: "POST",
                    encType: "multipart/form-data",
                    data: r
                }
            }
            var _ = a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ContextRegistry;

            function y(e, t, r, n) {
                this.status = e, this.value = t, this.reason = r, this._response = n
            }

            function w(e) {
                switch (e.status) {
                    case "resolved_model":
                        E(e);
                        break;
                    case "resolved_module":
                        R(e)
                }
                switch (e.status) {
                    case "fulfilled":
                        return e.value;
                    case "pending":
                    case "blocked":
                        throw e;
                    default:
                        throw e.reason
                }
            }

            function g(e, t) {
                for (var r = 0; r < e.length; r++)(0, e[r])(t)
            }

            function S(e, t, r) {
                switch (e.status) {
                    case "fulfilled":
                        g(t, e.value);
                        break;
                    case "pending":
                    case "blocked":
                        e.value = t, e.reason = r;
                        break;
                    case "rejected":
                        r && g(r, e.reason)
                }
            }

            function k(e, t) {
                if ("pending" === e.status || "blocked" === e.status) {
                    var r = e.reason;
                    e.status = "rejected", e.reason = t, null !== r && g(r, t)
                }
            }

            function N(e, t) {
                if ("pending" === e.status || "blocked" === e.status) {
                    var r = e.value,
                        n = e.reason;
                    e.status = "resolved_module", e.value = t, null !== r && (R(e), S(e, r, n))
                }
            }
            y.prototype = Object.create(Promise.prototype), y.prototype.then = function(e, t) {
                switch (this.status) {
                    case "resolved_model":
                        E(this);
                        break;
                    case "resolved_module":
                        R(this)
                }
                switch (this.status) {
                    case "fulfilled":
                        e(this.value);
                        break;
                    case "pending":
                    case "blocked":
                        e && (null === this.value && (this.value = []), this.value.push(e)), t && (null === this.reason && (this.reason = []), this.reason.push(t));
                        break;
                    default:
                        t(this.reason)
                }
            };
            var O = null,
                x = null;

            function E(e) {
                var t = O,
                    r = x;
                O = e, x = null;
                try {
                    var n = JSON.parse(e.value, e._response._fromJSON);
                    null !== x && 0 < x.deps ? (x.value = n, e.status = "blocked", e.value = null, e.reason = null) : (e.status = "fulfilled", e.value = n)
                } catch (t) {
                    e.status = "rejected", e.reason = t
                } finally {
                    O = t, x = r
                }
            }

            function R(e) {
                try {
                    var t = e.value;
                    if (t.async) {
                        var r = l.get(t.id);
                        if ("fulfilled" === r.status) var n = r.value;
                        else throw r.reason
                    } else n = globalThis.__next_require__(t.id);
                    var a = "*" === t.name ? n : "" === t.name ? n.__esModule ? n.default : n : n[t.name];
                    e.status = "fulfilled", e.value = a
                } catch (t) {
                    e.status = "rejected", e.reason = t
                }
            }

            function T(e, t) {
                e._chunks.forEach(function(e) {
                    "pending" === e.status && k(e, t)
                })
            }

            function $(e, t) {
                var r = e._chunks,
                    n = r.get(t);
                return n || (n = new y("pending", null, null, e), r.set(t, n)), n
            }

            function j() {
                throw Error('Trying to call a function from "use server" but the callServer option was not implemented in your router runtime.')
            }

            function D(e, t) {
                var r;
                return (e = {
                    _bundlerConfig: e,
                    _callServer: void 0 !== t ? t : j,
                    _chunks: new Map,
                    _partialRow: "",
                    _stringDecoder: null,
                    _fromJSON: null
                })._stringDecoder = new TextDecoder, e._fromJSON = (r = e, function(e, t) {
                    return "string" == typeof t ? function(e, t, r, n) {
                        if ("$" === n[0]) {
                            if ("$" === n) return c;
                            switch (n[1]) {
                                case "$":
                                    return n.slice(1);
                                case "L":
                                    return {
                                        $$typeof: f,
                                        _payload: e = $(e, t = parseInt(n.slice(2), 16)),
                                        _init: w
                                    };
                                case "@":
                                    return $(e, t = parseInt(n.slice(2), 16));
                                case "S":
                                    return Symbol.for(n.slice(2));
                                case "P":
                                    return _[e = n.slice(2)] || (_[e] = a.createServerContext(e, d)), _[e].Provider;
                                case "F":
                                    if ("resolved_model" === (t = $(e, t = parseInt(n.slice(2), 16))).status && E(t), "fulfilled" === t.status) return function(e, t) {
                                        function r() {
                                            var e = Array.prototype.slice.call(arguments),
                                                r = t.bound;
                                            return r ? "fulfilled" === r.status ? n(t.id, r.value.concat(e)) : Promise.resolve(r).then(function(r) {
                                                return n(t.id, r.concat(e))
                                            }) : n(t.id, e)
                                        }
                                        var n = e._callServer;
                                        return r.$$FORM_ACTION = b, h.set(r, t), r
                                    }(e, t.value);
                                    throw t.reason;
                                case "I":
                                    return 1 / 0;
                                case "-":
                                    return "$-0" === n ? -0 : -1 / 0;
                                case "N":
                                    return NaN;
                                case "u":
                                    return;
                                case "D":
                                    return new Date(Date.parse(n.slice(2)));
                                case "n":
                                    return BigInt(n.slice(2));
                                default:
                                    switch ((e = $(e, n = parseInt(n.slice(1), 16))).status) {
                                        case "resolved_model":
                                            E(e);
                                            break;
                                        case "resolved_module":
                                            R(e)
                                    }
                                    switch (e.status) {
                                        case "fulfilled":
                                            return e.value;
                                        case "pending":
                                        case "blocked":
                                            var o;
                                            return n = O, e.then(function(e, t, r) {
                                                if (x) {
                                                    var n = x;
                                                    n.deps++
                                                } else n = x = {
                                                    deps: 1,
                                                    value: null
                                                };
                                                return function(a) {
                                                    t[r] = a, n.deps--, 0 === n.deps && "blocked" === e.status && (a = e.value, e.status = "fulfilled", e.value = n.value, null !== a && g(a, n.value))
                                                }
                                            }(n, t, r), (o = n, function(e) {
                                                return k(o, e)
                                            })), null;
                                        default:
                                            throw e.reason
                                    }
                            }
                        }
                        return n
                    }(r, this, e, t) : "object" == typeof t && null !== t ? e = t[0] === c ? {
                        $$typeof: c,
                        type: t[1],
                        key: t[2],
                        ref: null,
                        props: t[3],
                        _owner: null
                    } : t : t
                }), e
            }

            function I() {
                throw Error("Server Functions cannot be called during initial render. This would create a fetch waterfall. Try to use a Server Component to pass data to Client Components instead.")
            }

            function C(e, t) {
                function r(t) {
                    T(e, t)
                }
                var n = t.getReader();
                n.read().then(function t(a) {
                    var c = a.value;
                    if (a.done) T(e, Error("Connection closed."));
                    else {
                        a = c, c = e._stringDecoder;
                        for (var f = a.indexOf(10); - 1 < f;) {
                            var d = e._partialRow,
                                p = a.subarray(0, f);
                            p = c.decode(p);
                            var v = d + p;
                            if (d = e, "" !== v) {
                                var h = v.indexOf(":", 0);
                                switch (p = parseInt(v.slice(0, h), 16), v[h + 1]) {
                                    case "I":
                                        ! function(e, t, r) {
                                            var n = e._chunks,
                                                a = n.get(t);
                                            r = JSON.parse(r, e._fromJSON);
                                            var o = function(e, t) {
                                                if (e) {
                                                    var r = e[t.id];
                                                    if (e = r[t.name]) r = e.name;
                                                    else {
                                                        if (!(e = r["*"])) throw Error('Could not find the module "' + t.id + '" in the React SSR Manifest. This is probably a bug in the React Server Components bundler.');
                                                        r = t.name
                                                    }
                                                    return {
                                                        id: e.id,
                                                        chunks: e.chunks,
                                                        name: r,
                                                        async: !!t.async
                                                    }
                                                }
                                                return t
                                            }(e._bundlerConfig, r);
                                            if (r = function(e) {
                                                    for (var t = e.chunks, r = [], n = 0; n < t.length; n++) {
                                                        var a = t[n],
                                                            o = s.get(a);
                                                        if (void 0 === o) {
                                                            o = globalThis.__next_chunk_load__(a), r.push(o);
                                                            var i = s.set.bind(s, a, null);
                                                            o.then(i, u), s.set(a, o)
                                                        } else null !== o && r.push(o)
                                                    }
                                                    if (e.async) {
                                                        if (t = l.get(e.id)) return "fulfilled" === t.status ? null : t;
                                                        var c = Promise.all(r).then(function() {
                                                            return globalThis.__next_require__(e.id)
                                                        });
                                                        return c.then(function(e) {
                                                            c.status = "fulfilled", c.value = e
                                                        }, function(e) {
                                                            c.status = "rejected", c.reason = e
                                                        }), l.set(e.id, c), c
                                                    }
                                                    return 0 < r.length ? Promise.all(r) : null
                                                }(o)) {
                                                if (a) {
                                                    var i = a;
                                                    i.status = "blocked"
                                                } else i = new y("blocked", null, null, e), n.set(t, i);
                                                r.then(function() {
                                                    return N(i, o)
                                                }, function(e) {
                                                    return k(i, e)
                                                })
                                            } else a ? N(a, o) : n.set(t, new y("resolved_module", o, null, e))
                                        }(d, p, v.slice(h + 2));
                                        break;
                                    case "H":
                                        p = v[h + 2], d = JSON.parse(v = v.slice(h + 3), d._fromJSON), v = void 0;
                                        var m = i.current;
                                        if (m) switch ("string" == typeof d ? h = d : (h = d[0], v = d[1]), p) {
                                            case "D":
                                                m.prefetchDNS(h, v);
                                                break;
                                            case "C":
                                                m.preconnect(h, v);
                                                break;
                                            case "L":
                                                m.preload(h, v);
                                                break;
                                            case "I":
                                                m.preinit(h, v)
                                        }
                                        break;
                                    case "E":
                                        h = JSON.parse(v.slice(h + 2)).digest, (v = Error("An error occurred in the Server Components render. The specific message is omitted in production builds to avoid leaking sensitive details. A digest property is included on this error instance which may provide additional details about the nature of the error.")).stack = "Error: " + v.message, v.digest = h, (m = (h = d._chunks).get(p)) ? k(m, v) : h.set(p, new y("rejected", null, v, d));
                                        break;
                                    default:
                                        v = v.slice(h + 1), (m = (h = d._chunks).get(p)) ? (d = m, p = v, "pending" === d.status && (v = d.value, h = d.reason, d.status = "resolved_model", d.value = p, null !== v && (E(d), S(d, v, h)))) : h.set(p, new y("resolved_model", v, null, d))
                                }
                            }
                            e._partialRow = "", f = (a = a.subarray(f + 1)).indexOf(10)
                        }
                        return e._partialRow += c.decode(a, o), n.read().then(t).catch(r)
                    }
                }).catch(r)
            }
            t.createFromFetch = function(e, t) {
                var r = D(t && t.moduleMap ? t.moduleMap : null, I);
                return e.then(function(e) {
                    C(r, e.body)
                }, function(e) {
                    T(r, e)
                }), $(r, 0)
            }, t.createFromReadableStream = function(e, t) {
                return C(t = D(t && t.moduleMap ? t.moduleMap : null, I), e), $(t, 0)
            }, t.createServerReference = function() {
                return I
            }
        },
        6722: function(e, t, r) {
            "use strict";
            e.exports = r(6246)
        }
    },
    function(e) {
        e.O(0, [704, 801, 744], function() {
            return e(e.s = 4700)
        }), _N_E = e.O()
    }
]);